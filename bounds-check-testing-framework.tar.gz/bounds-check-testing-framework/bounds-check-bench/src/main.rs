//! Tier 3 + Tier 4 device-only timing harness (design doc §4-5).
//!
//! Verified against `wgpu` source directly (not assumed from a description):
//! `Features::TIMESTAMP_QUERY` is, per its own doc comment in
//! `wgpu-types/src/features.rs`, "a web and native feature" supported on
//! Vulkan/DX12/Metal/WebGPU - which is why this harness uses ONLY
//! `ComputePassDescriptor::timestamp_writes` (pass-level start/end) and
//! deliberately avoids `Features::TIMESTAMP_QUERY_INSIDE_PASSES`, which is
//! native-only and, per its own doc comment, not supported on all GPU
//! architectures even natively. Using only the portable mechanism means this
//! exact harness's `Restrict`-policy measurement - the one that matters for
//! browser WebGPU, the dominant deployment target - is the same code path
//! you'd run in a browser, not a native-only stand-in for it.
//!
//! The resolve/copy/map sequence below is adapted directly from the working
//! `wgpu` repo example at `examples/features/src/timestamp_queries/mod.rs`,
//! trimmed to the compute-only case this benchmark needs.

const WORKGROUP_COUNT: u32 = 256;
const DISPATCHES_PER_PASS: u32 = 10_000; // amortizes pass-setup overhead, not just host launch overhead - see design doc §4 step 2
const WARMUP_PASSES: u32 = 10;
const TIMED_PASSES: u32 = 1_000;

/// Which of this paper's three real baselines (§4.4 of the design doc) a run
/// is exercising. Do not add a fourth "vendor" or "CPU fallback" baseline
/// here without re-reading why that was flagged as a strawman risk.
#[derive(Clone, Copy, Debug)]
enum Baseline {
    Unchecked,
    ReadZeroSkipWrite,
    Restrict,
}

impl Baseline {
    fn naga_policy(self) -> naga::proc::BoundsCheckPolicy {
        match self {
            Baseline::Unchecked => naga::proc::BoundsCheckPolicy::Unchecked,
            Baseline::ReadZeroSkipWrite => naga::proc::BoundsCheckPolicy::ReadZeroSkipWrite,
            Baseline::Restrict => naga::proc::BoundsCheckPolicy::Restrict,
        }
    }
}

/// TODO(you): replace with the real reduction / prefix-scan / tiled-GEMM
/// kernels from the paper's §6 Tier 4. This placeholder exists only so the
/// timing/feature-gating plumbing below is runnable and testable on its own
/// before the kernel-specific work lands. Each kernel string should come in
/// two variants - "baseline" (today's Naga output) and "patched" (after the
/// §4.2 transform) - so a single run of this harness can report both sides
/// of the before/after comparison in one table.
const PLACEHOLDER_KERNEL_WGSL: &str = r#"
    var<workgroup> tile: array<f32, 64>;
    @group(0) @binding(0) var<storage, read_write> out: array<f32>;

    @compute @workgroup_size(64)
    fn main(@builtin(local_invocation_index) lid: u32,
            @builtin(workgroup_id) wid: vec3<u32>) {
        tile[lid] = f32(lid);
        workgroupBarrier();
        out[wid.x] = tile[0];
    }
"#;

struct TimestampQueries {
    set: wgpu::QuerySet,
    resolve_buffer: wgpu::Buffer,
    destination_buffer: wgpu::Buffer,
}

impl TimestampQueries {
    /// `num_queries` = 2 per timed pass (start, end). We allocate for exactly
    /// the run we're about to do, rather than a fixed constant, so Tier 4's
    /// multi-kernel runs don't silently truncate.
    fn new(device: &wgpu::Device, num_queries: u64) -> Self {
        let byte_size = std::mem::size_of::<u64>() as u64 * num_queries;
        Self {
            set: device.create_query_set(&wgpu::QuerySetDescriptor {
                label: Some("bounds-check-elision timestamp set"),
                count: num_queries as u32,
                ty: wgpu::QueryType::Timestamp,
            }),
            resolve_buffer: device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("timestamp resolve buffer"),
                size: byte_size,
                usage: wgpu::BufferUsages::COPY_SRC | wgpu::BufferUsages::QUERY_RESOLVE,
                mapped_at_creation: false,
            }),
            // QUERY_RESOLVE and MAP_READ cannot be combined on one buffer -
            // verified directly against the working example; this is the
            // mandatory second buffer + copy, not an optional simplification.
            destination_buffer: device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("timestamp destination buffer"),
                size: byte_size,
                usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
                mapped_at_creation: false,
            }),
        }
    }

    fn resolve(&self, encoder: &mut wgpu::CommandEncoder, num_queries: u32) {
        encoder.resolve_query_set(&self.set, 0..num_queries, &self.resolve_buffer, 0);
        encoder.copy_buffer_to_buffer(
            &self.resolve_buffer,
            0,
            &self.destination_buffer,
            0,
            self.resolve_buffer.size(),
        );
    }

    fn read_back(&self, device: &wgpu::Device) -> Vec<u64> {
        self.destination_buffer
            .slice(..)
            .map_async(wgpu::MapMode::Read, |_| ());
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let timestamps = {
            let view = self.destination_buffer.slice(..).get_mapped_range();
            bytemuck::cast_slice::<u8, u64>(&view).to_vec()
        };
        self.destination_buffer.unmap();
        timestamps
    }
}

/// Runs `DISPATCHES_PER_PASS` dispatches inside ONE compute pass, bracketed
/// by start/end timestamps written via `ComputePassDescriptor::timestamp_writes`
/// - the portable, web-and-native mechanism. Repeats `TIMED_PASSES` times
/// after `WARMUP_PASSES` untimed warm-up passes (mirrors the paper's own
/// "100 samples, discard the first" precedent, applied per-pass rather than
/// per-dispatch since pass setup, not dispatch count, is the thing being
/// amortized here).
async fn time_one_baseline(
    device: &wgpu::Device,
    queue: &wgpu::Queue,
    pipeline: &wgpu::ComputePipeline,
    bind_group: &wgpu::BindGroup,
) -> Vec<f64> {
    let period = queue.get_timestamp_period(); // NOT 1.0 in general - backend/device dependent, verified against wgpu source doc comment
    let mut samples_us = Vec::with_capacity(TIMED_PASSES as usize);

    for pass_index in 0..(WARMUP_PASSES + TIMED_PASSES) {
        let is_warmup = pass_index < WARMUP_PASSES;
        let queries = TimestampQueries::new(device, 2);

        let mut encoder = device.create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("bounds-check-elision timing encoder"),
        });
        {
            let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
                label: Some("timed pass"),
                timestamp_writes: Some(wgpu::ComputePassTimestampWrites {
                    query_set: &queries.set,
                    beginning_of_pass_write_index: Some(0),
                    end_of_pass_write_index: Some(1),
                }),
            });
            pass.set_pipeline(pipeline);
            pass.set_bind_group(0, bind_group, &[]);
            for _ in 0..DISPATCHES_PER_PASS {
                pass.dispatch_workgroups(WORKGROUP_COUNT, 1, 1);
            }
        }
        queries.resolve(&mut encoder, 2);
        queue.submit(Some(encoder.finish()));

        if is_warmup {
            // Still must drain the queue so the next pass doesn't queue up
            // unboundedly, but we don't care about its timing.
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            continue;
        }

        let ticks = queries.read_back(device);
        let elapsed_ticks = ticks[1].wrapping_sub(ticks[0]);
        let elapsed_ns = elapsed_ticks as f64 * period as f64;
        let elapsed_us_per_dispatch = (elapsed_ns / 1000.0) / DISPATCHES_PER_PASS as f64;
        samples_us.push(elapsed_us_per_dispatch);
    }

    samples_us
}

fn median(samples: &mut [f64]) -> f64 {
    samples.sort_by(|a, b| a.partial_cmp(b).unwrap());
    samples[samples.len() / 2]
}

fn p95(samples: &mut [f64]) -> f64 {
    samples.sort_by(|a, b| a.partial_cmp(b).unwrap());
    samples[(samples.len() as f64 * 0.95) as usize]
}

/// TODO(you): wire this up to actually compile `PLACEHOLDER_KERNEL_WGSL`
/// through naga with `baseline.naga_policy()` (mirroring
/// `elision_assertions.rs`'s `compile_to_spv_text` helper, but feeding the
/// result into `device.create_shader_module` instead of `rspirv::disassemble`),
/// build the pipeline/bind group, and call `time_one_baseline`. This function
/// is left as a stub with the right signature and the feature-request logic
/// filled in, since THAT part - not the kernel plumbing - is what needed
/// verifying against the real API before being worth handing to you.
async fn run_one_baseline(baseline: Baseline) -> anyhow::Result<(f64, f64)> {
    let instance = wgpu::Instance::default();
    let adapter = instance
        .request_adapter(&wgpu::RequestAdapterOptions::default())
        .await?;

    // TIMESTAMP_QUERY only - deliberately NOT requesting
    // TIMESTAMP_QUERY_INSIDE_PASSES/_ENCODERS, since this harness only needs
    // pass-level start/end timestamps and we want this code path to be the
    // same one that would run under real WebGPU in a browser.
    let required_features = wgpu::Features::TIMESTAMP_QUERY;
    if !adapter.features().contains(required_features) {
        anyhow::bail!(
            "adapter does not support Features::TIMESTAMP_QUERY; \
             Tier 3 measurements are not possible on this device/backend combination - \
             report this in the paper's evaluation section as a coverage gap, not a silent skip."
        );
    }

    let (device, queue) = adapter
        .request_device(&wgpu::DeviceDescriptor {
            required_features,
            ..Default::default()
        })
        .await?;

    let _ = baseline.naga_policy(); // TODO(you): thread into the shader-module build step

    // TODO(you): build `pipeline` and `bind_group` for PLACEHOLDER_KERNEL_WGSL
    // under `baseline.naga_policy()`, then:
    // let mut samples = time_one_baseline(&device, &queue, &pipeline, &bind_group).await;
    let mut samples: Vec<f64> = vec![0.0]; // placeholder so the function returns something

    Ok((median(&mut samples), p95(&mut samples)))
}

fn main() -> anyhow::Result<()> {
    pollster::block_on(async {
        println!(
            "{:<20} {:>12} {:>12}",
            "baseline", "median (us)", "p95 (us)"
        );
        for baseline in [
            Baseline::Unchecked,
            Baseline::ReadZeroSkipWrite,
            Baseline::Restrict,
        ] {
            let (median_us, p95_us) = run_one_baseline(baseline).await?;
            println!("{baseline:<20?} {median_us:>12.3} {p95_us:>12.3}");
        }
        Ok(())
    })
}
